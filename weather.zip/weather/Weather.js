const React = require('react');
const axios = require('axios');
const FormContainer = require('./component/FormContainer');
const RightPanel = require('./component/RightPanel');
const LeftPanel = require('./component/LeftPanel');

class Weather extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      zipCode: '',
      weather: ''
    };
  }
  /* onChangeHandler sets the targetted value of input field */
  onChangeHandler = (e) => {
    this.setState({
      zipCode: e.target.value
    });
  }

  /* handlesubmit makes asyn call with get the Weather data and set it to weather variable */
  handleSubmit = async (event) => {
    event.preventDefault();
      /* Additonal Param to make http get Request */
    const options = {
      method: "GET",
      url: "https://weather-by-api-ninjas.p.rapidapi.com/v1/weather",
      params: { zip: this.state.zipCode },
      headers: {
        "X-RapidAPI-Key": "d3931ef1ffmsh3a12f419374628cp1974c3jsn4336881f72c2",
        "X-RapidAPI-Host": "weather-by-api-ninjas.p.rapidapi.com"
      }
    };

    try {
      axios
        .request(options)
        .then(response => {
          this.setState({
            weather: response.data
          });
        })
        .catch((error) => console.error(error));
    } catch (error) {
      this.setState({
        weather: ''
      });
      console.error(error);
    }
  };

  render() {
      const date = new Date()?.toLocaleString();

      return (
        <div className="App">
          <div classNmae="app-container">
            <FormContainer
              title={"Weather App"}
              placeholder={"Enter zip code"}
              onChange={this.onChangeHandler}
              handleSubmit={this.handleSubmit}
              value={this.state.zipCode}
              buttonName={"Get Weather"}
              disabled={this.state.zipCode === ''}
            />
            {this.state.weather && (
              <div className={"weather-card card-module"}>
                <div className={"weather-card__body"}>
                  <LeftPanel
                    title={'Date and Time'}
                    subTitle={date}
                    temp={this.state.weather.temp}
                    feelsLike={this.state.weather.feels_like}
                  />
                  <div className={"weather-card__panel details-container"}>
                    <RightPanel label={"Air Quality"} styled labelValue={"Average"} />
                    <RightPanel label={"Wind"} labelValue={`${this.state.weather.wind_speed} mph`} />
                    <RightPanel label={"Humidity"} labelValue={`${this.state.weather.humidity} %`} />
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      );
  }
}

module.exports = Weather;