const React = require('react');
const PropTypes = require('prop-types');

class RightPanel extends React.Component {
  render() {
    const { label, labelValue, styled } = this.props
    return (
      <div className={'spaced-content detail'}>
        <span className={'label'}>{label}</span>
        <span className={styled ? 'value redValue' : 'value'}>{labelValue}</span>
      </div>
    );
  }
};

RightPanel.propTypes = {
  label: PropTypes.string,
  labelValue: PropTypes.func,
  styled: PropTypes.bool,
};

module.exports = RightPanel;
