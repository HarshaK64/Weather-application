const React = require('react');
const PropTypes = require('prop-types');

class LeftPanel extends React.Component {
  render() {
    const { title, subTitle, temp, feelsLike } = this.props
    return (
        <div className={"weather-card__panel"}>
            <h2 className={"weather-card__title"}>{title}</h2>
            <p className={"weather-card__subtitle"}>{subTitle}</p>
            <div className={"forecast-container"}>
            <div className={"temp-container"}>
                <div className={"temp"}>
                    {temp}° <span className="after-temp">C</span>
                </div>
                <div className="real-feel">
                    RealFeel® {feelsLike}°
                </div>
            </div>
            </div>
      </div>
    );
  }
};

LeftPanel.propTypes = {
    title: PropTypes.string,
    subTitle: PropTypes.string,
    temp: PropTypes.string,
    feelsLike: PropTypes.string
};

module.exports = LeftPanel;
