const React = require('react');
const PropTypes = require('prop-types');
const Input = require('swa-components-core/input');
const Button = require('swa-components-core/button');

class FormContainer extends React.Component {
  render() {
    const { placeholder, onChange, value, handleSubmit, buttonName, title, disabled } = this.props
    return (
      <div className="form-container">
        <h1 className="title">{title}</h1>
        <h6>{placeholder}</h6>
        <Input className="input_50"
          inputType="primary-simple"
          onChange={onChange}
          value={value}
        />
        <div className='button-bar'>
          <Button onClick={handleSubmit} disabled={disabled} largeSized={true} buttonType={'primary'}>{buttonName}</Button>
        </div>
      </div>
    );
  }
};

FormContainer.propTypes = {
  placeholder: PropTypes.string,
  title: PropTypes.string,
  handleSubmit: PropTypes.func,
  onChange: PropTypes.func,
  value: PropTypes.string,
  buttonName: PropTypes.string,
  disabled: PropTypes.bool
};

module.exports = FormContainer;
