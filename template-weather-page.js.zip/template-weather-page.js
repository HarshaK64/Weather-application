const i18n = require('swa-locale/i18n');
const Link = require('swa-components-core/link');
const PlacementFactory = require('swa-content-core/placement-factory');
const React = require('react');
const urls = require('swa-bootstrap-data/urls');
const Weather = require('./weather/Weather');

class TemplateWeatherPage extends React.Component {
    render() {
        return (
            <div {...this.getProps()}>
                <div className="index-page--heading">Welcome to Weather Forecast</div>
                <Link {...this.getTemplateIndexLinkProps()}>
                    {i18n('LINK__TEMPLATE_INDEX')}
                </Link>
                <PlacementFactory placementId="templatePlacement" />
                <Weather />
            </div>
        );
    }
    getProps = () => ({
        className: 'template-index-page'
    });

    getTemplateIndexLinkProps = () => ({
        iconGap: 'large',
        linkSize: 'extra-small',
        linkType: 'light',
        route: {
            page: urls.TEMPLATE__INDEX_PAGE
        },
        suffixIcon: 'arrow-right',
        suffixIconSize: 'micro'
    });
}

module.exports = TemplateWeatherPage;
