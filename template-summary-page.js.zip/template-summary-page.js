const i18n = require('swa-locale/i18n');
const Link = require('swa-components-core/link');
const React = require('react');
const urls = require('swa-bootstrap-data/urls');
const PlacementFactory = require('swa-content-core/placement-factory');

class TemplateSummaryPage extends React.Component {
    render() {
        return (
            <div {...this.getProps()}>
                <div className="summary-page--heading">This is the summary page!</div>
                <Link {...this.getTemplateWeatherLinkProps()}>
                    {i18n('Go to Weather Page')}
                </Link>
                <PlacementFactory placementId="templatePlacement" />
            </div>
        );
    }

    getProps = () => ({
        className: 'template-summary-page'
    });

    getTemplateWeatherLinkProps = () => ({
        iconGap: 'large',
        linkSize: 'extra-small',
        linkType: 'light',
        route: {
            page: 'weather.html'
        },
        suffixIcon: 'arrow-right',
        suffixIconSize: 'micro'
    });
}

module.exports = TemplateSummaryPage;
